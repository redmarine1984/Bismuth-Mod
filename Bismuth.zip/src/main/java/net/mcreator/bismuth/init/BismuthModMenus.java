
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bismuth.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.bismuth.world.inventory.AlloyFurnaceMenu;
import net.mcreator.bismuth.BismuthMod;

public class BismuthModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, BismuthMod.MODID);
	public static final RegistryObject<MenuType<AlloyFurnaceMenu>> ALLOY_FURNACE = REGISTRY.register("alloy_furnace", () -> IForgeMenuType.create(AlloyFurnaceMenu::new));
}
