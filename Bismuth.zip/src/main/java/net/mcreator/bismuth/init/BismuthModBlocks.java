
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bismuth.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.bismuth.block.BismuthOREBlock;
import net.mcreator.bismuth.block.BismuthDeepSlateOreBlock;
import net.mcreator.bismuth.block.BismuthBronzeBlockBlock;
import net.mcreator.bismuth.block.BismuthBlockBlock;
import net.mcreator.bismuth.block.BismondPortalBlock;
import net.mcreator.bismuth.block.BismondBlockBlock;
import net.mcreator.bismuth.block.AlloyFurnaceBlockBlock;
import net.mcreator.bismuth.BismuthMod;

public class BismuthModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, BismuthMod.MODID);
	public static final RegistryObject<Block> BISMUTH_ORE = REGISTRY.register("bismuth_ore", () -> new BismuthOREBlock());
	public static final RegistryObject<Block> BISMUTH_DEEP_SLATE_ORE = REGISTRY.register("bismuth_deep_slate_ore", () -> new BismuthDeepSlateOreBlock());
	public static final RegistryObject<Block> BISMUTH_BLOCK = REGISTRY.register("bismuth_block", () -> new BismuthBlockBlock());
	public static final RegistryObject<Block> BISMUTH_BRONZE_BLOCK = REGISTRY.register("bismuth_bronze_block", () -> new BismuthBronzeBlockBlock());
	public static final RegistryObject<Block> ALLOY_FURNACE_BLOCK = REGISTRY.register("alloy_furnace_block", () -> new AlloyFurnaceBlockBlock());
	public static final RegistryObject<Block> BISMOND_PORTAL = REGISTRY.register("bismond_portal", () -> new BismondPortalBlock());
	public static final RegistryObject<Block> BISMOND_BLOCK = REGISTRY.register("bismond_block", () -> new BismondBlockBlock());
}
