
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bismuth.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.bismuth.BismuthMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BismuthModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BismuthMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(BismuthModBlocks.BISMUTH_ORE.get().asItem());
			tabData.accept(BismuthModBlocks.BISMUTH_DEEP_SLATE_ORE.get().asItem());
			tabData.accept(BismuthModBlocks.BISMUTH_BLOCK.get().asItem());
			tabData.accept(BismuthModBlocks.BISMUTH_BRONZE_BLOCK.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(BismuthModBlocks.ALLOY_FURNACE_BLOCK.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(BismuthModItems.BISMUTH_BRONZE_ARMOR_HELMET.get());
			tabData.accept(BismuthModItems.BISMUTH_BRONZE_ARMOR_CHESTPLATE.get());
			tabData.accept(BismuthModItems.BISMUTH_BRONZE_ARMOR_LEGGINGS.get());
			tabData.accept(BismuthModItems.BISMUTH_BRONZE_ARMOR_BOOTS.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(BismuthModItems.RAW_BISMUTH.get());
			tabData.accept(BismuthModItems.BISMUTH_BRONZE.get());
			tabData.accept(BismuthModItems.AMALGAMATE_DUST.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(BismuthModItems.BISMUTH_AXE.get());
			tabData.accept(BismuthModItems.BISMUTH_PICK_AXE.get());
			tabData.accept(BismuthModItems.BISMUTH_SWORD.get());
			tabData.accept(BismuthModItems.BISMUTH_HOE.get());
			tabData.accept(BismuthModItems.BISMUTH_SHOVEL.get());
			tabData.accept(BismuthModItems.BISMUTH_SHEARS.get());
			tabData.accept(BismuthModItems.BISMOND.get());
		}
	}
}
