
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bismuth.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.bismuth.item.RawBismuthItem;
import net.mcreator.bismuth.item.GoldDustItem;
import net.mcreator.bismuth.item.BismuthSwordItem;
import net.mcreator.bismuth.item.BismuthShovelItem;
import net.mcreator.bismuth.item.BismuthShearsItem;
import net.mcreator.bismuth.item.BismuthPickAxeItem;
import net.mcreator.bismuth.item.BismuthHoeItem;
import net.mcreator.bismuth.item.BismuthBronzeItem;
import net.mcreator.bismuth.item.BismuthBronzeArmorItem;
import net.mcreator.bismuth.item.BismuthAxeItem;
import net.mcreator.bismuth.item.BismondItem;
import net.mcreator.bismuth.item.AmalgamateDustItem;
import net.mcreator.bismuth.BismuthMod;

public class BismuthModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BismuthMod.MODID);
	public static final RegistryObject<Item> RAW_BISMUTH = REGISTRY.register("raw_bismuth", () -> new RawBismuthItem());
	public static final RegistryObject<Item> BISMUTH_ORE = block(BismuthModBlocks.BISMUTH_ORE);
	public static final RegistryObject<Item> BISMUTH_BRONZE = REGISTRY.register("bismuth_bronze", () -> new BismuthBronzeItem());
	public static final RegistryObject<Item> BISMUTH_AXE = REGISTRY.register("bismuth_axe", () -> new BismuthAxeItem());
	public static final RegistryObject<Item> BISMUTH_PICK_AXE = REGISTRY.register("bismuth_pick_axe", () -> new BismuthPickAxeItem());
	public static final RegistryObject<Item> BISMUTH_SWORD = REGISTRY.register("bismuth_sword", () -> new BismuthSwordItem());
	public static final RegistryObject<Item> BISMUTH_HOE = REGISTRY.register("bismuth_hoe", () -> new BismuthHoeItem());
	public static final RegistryObject<Item> BISMUTH_SHOVEL = REGISTRY.register("bismuth_shovel", () -> new BismuthShovelItem());
	public static final RegistryObject<Item> BISMUTH_DEEP_SLATE_ORE = block(BismuthModBlocks.BISMUTH_DEEP_SLATE_ORE);
	public static final RegistryObject<Item> BISMUTH_SHEARS = REGISTRY.register("bismuth_shears", () -> new BismuthShearsItem());
	public static final RegistryObject<Item> BISMUTH_BRONZE_ARMOR_HELMET = REGISTRY.register("bismuth_bronze_armor_helmet", () -> new BismuthBronzeArmorItem.Helmet());
	public static final RegistryObject<Item> BISMUTH_BRONZE_ARMOR_CHESTPLATE = REGISTRY.register("bismuth_bronze_armor_chestplate", () -> new BismuthBronzeArmorItem.Chestplate());
	public static final RegistryObject<Item> BISMUTH_BRONZE_ARMOR_LEGGINGS = REGISTRY.register("bismuth_bronze_armor_leggings", () -> new BismuthBronzeArmorItem.Leggings());
	public static final RegistryObject<Item> BISMUTH_BRONZE_ARMOR_BOOTS = REGISTRY.register("bismuth_bronze_armor_boots", () -> new BismuthBronzeArmorItem.Boots());
	public static final RegistryObject<Item> BISMUTH_BLOCK = block(BismuthModBlocks.BISMUTH_BLOCK);
	public static final RegistryObject<Item> BISMUTH_BRONZE_BLOCK = block(BismuthModBlocks.BISMUTH_BRONZE_BLOCK);
	public static final RegistryObject<Item> ALLOY_FURNACE_BLOCK = block(BismuthModBlocks.ALLOY_FURNACE_BLOCK);
	public static final RegistryObject<Item> BISMOND = REGISTRY.register("bismond", () -> new BismondItem());
	public static final RegistryObject<Item> AMALGAMATE_DUST = REGISTRY.register("amalgamate_dust", () -> new AmalgamateDustItem());
	public static final RegistryObject<Item> GOLD_DUST = REGISTRY.register("gold_dust", () -> new GoldDustItem());
	public static final RegistryObject<Item> BISMOND_BLOCK = block(BismuthModBlocks.BISMOND_BLOCK);

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
